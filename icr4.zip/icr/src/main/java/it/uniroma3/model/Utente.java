package it.uniroma3.model;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
public class Utente {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column
    private String username;

    @Column
    private String password;

    @Column
    private String nome;

    @Column
    private String cognome;

    @Column
    private Date dataCreazione;

    @Column
    private String role;

    @ManyToMany
    private List<Progetto> progettiVisibili;

    @OneToMany(mappedBy = "utente")
    private List<Progetto> progetti;

    @OneToOne(mappedBy = "utente")
    private Task task;

    public Utente() {
        this.role = "ROLE_USER";
    }

    public List<Progetto> getProgettiVisibili() {
        return progettiVisibili;
    }

    public void setProgettiVisibili(List<Progetto> progettiVisibili) {
        this.progettiVisibili = progettiVisibili;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Task getTask() {
        return task;
    }

    public void setTask(Task task) {
        this.task = task;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public Date getDataCreazione() {
        return dataCreazione;
    }

    public void setDataCreazione(Date dataCreazione) {
        this.dataCreazione = dataCreazione;
    }

    public List<Progetto> getProgetti() {
        return progetti;
    }

    public void setProgetti(List<Progetto> progetti) {
        this.progetti = progetti;
    }
}
