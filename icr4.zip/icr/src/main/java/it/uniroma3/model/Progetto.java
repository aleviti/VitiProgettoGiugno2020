package it.uniroma3.model;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
public class Progetto {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(nullable = false)
    private String nome;

    @Column(nullable = false)
    private Date dataInizio;

    @ManyToMany(mappedBy = "progettiVisibili")
    private List<Utente> utentiCondivisi;

    @OneToMany(mappedBy = "progetto")
    private List<Task> tasks;

    @ManyToOne
    private Utente utente;

    public List<Utente> getUtentiCondivisi() {
        return utentiCondivisi;
    }

    public void setUtentiCondivisi(List<Utente> utentiCondivisi) {
        this.utentiCondivisi = utentiCondivisi;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getDataInizio() {
        return dataInizio;
    }

    public void setDataInizio(Date dataInizio) {
        this.dataInizio = dataInizio;
    }

    public List<Task> getTasks() {
        return tasks;
    }

    public void setTasks(List<Task> tasks) {
        this.tasks = tasks;
    }

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }
}
