package it.uniroma3;

import it.uniroma3.model.Utente;
import org.springframework.ui.Model;

import javax.servlet.http.HttpSession;

public class UtenteValidator {

    public static boolean validate(Utente utente,Utente u, Model model, HttpSession session) {
        boolean verifica = true;

        session.setAttribute("utente",utente);

        if (utente.getNome().equals("")) {
            verifica = false;
            session.setAttribute("errNome","*Campo Obbligatorio");
            model.addAttribute("errName", "*Campo obbligatorio");
        }
        if (utente.getCognome().equals("")) {
            verifica = false;
            session.setAttribute("errCognome","*Campo Obbligatorio");
            model.addAttribute("errSurname", "*Campo obbligatorio");
        }
        if (utente.getUsername().equals("")) {
            verifica = false;
            session.setAttribute("errUsername","*Campo Obbligatorio");
            model.addAttribute("errUsername", "*Campo obbligatorio");
        }
        if (utente.getPassword().equals("")) {
            verifica = false;
            session.setAttribute("errPassword","*Campo Obbligatorio");
            model.addAttribute("errPassword", "*Campo obbligatorio");
        }

        if (utente != null ) {
            verifica = false;
            session.setAttribute("usernameError","Username gia' esistente");
            model.addAttribute("usernameError", "Username gia' esistente");
        }

        return verifica;
    }

}
