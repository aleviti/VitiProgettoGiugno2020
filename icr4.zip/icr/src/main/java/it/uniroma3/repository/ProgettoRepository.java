package it.uniroma3.repository;


import it.uniroma3.model.Progetto;
import org.springframework.data.repository.CrudRepository;

public interface ProgettoRepository extends CrudRepository<Progetto,Long> {
	 Progetto findByNome(String nome);
}
