package it.uniroma3.repository;

import it.uniroma3.model.Amministratore;
import org.springframework.data.repository.CrudRepository;

public interface AmministratoreRepository extends CrudRepository<Amministratore,Long> {

    Amministratore findByUsername(String username);
}
