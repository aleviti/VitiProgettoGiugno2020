package it.uniroma3.repository;

import it.uniroma3.model.Utente;
import org.springframework.data.repository.CrudRepository;

public interface UtenteRepository extends CrudRepository<Utente,Long> {

    Utente findByUsername(String username);

}
