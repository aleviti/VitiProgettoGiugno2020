package it.uniroma3.controller;

import it.uniroma3.UtenteValidator;
import it.uniroma3.model.Utente;
import it.uniroma3.repository.UtenteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;
import java.util.Calendar;

@Controller
public class UtenteController {

    @Autowired
    private UtenteRepository utenteRepository;

    @RequestMapping(value={"/toRegistrazione"}, method={org.springframework.web.bind.annotation.RequestMethod.GET})
    public String toRegistrazione(Model model)
    {
        model.addAttribute("utente", new Utente());
        return "registrazione";
    }

    @RequestMapping(value={"/registrati"}, method={org.springframework.web.bind.annotation.RequestMethod.POST})
    public String registrati(Model model, @ModelAttribute Utente utente, HttpSession session) {

        Utente u = utenteRepository.findByUsername(utente.getUsername());

        //if(UtenteValidator.validate(utente,u,model,session)) {
            PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

            Calendar sysdate = Calendar.getInstance();
            utente.setDataCreazione(sysdate.getTime());
            String passwordEncode = passwordEncoder.encode(utente.getPassword());
            utente.setPassword(passwordEncode);
            model.addAttribute("utente", utente);
            utenteRepository.save(utente);
            return "index";
        //} else {
        //    return "registrazione";
        //}
    }
    
  

}
