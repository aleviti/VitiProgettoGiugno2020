package it.uniroma3.controller;

import it.uniroma3.model.Amministratore;
import it.uniroma3.model.Utente;
import it.uniroma3.repository.AmministratoreRepository;
import it.uniroma3.repository.UtenteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Controller
public class LoginController {

    @Autowired
    private UtenteRepository utenteRepository;

    @Autowired
    private AmministratoreRepository amministratoreRepository;



    @RequestMapping(value={"/login"}, method={org.springframework.web.bind.annotation.RequestMethod.GET})
    public String login(ModelMap model, @RequestParam(value="error", required=false) String error)
    {
        if (error != null) {
            model.addAttribute("error", "Username o password non validi");
        }
        model.addAttribute("utente", new Utente());
        model.addAttribute("amministratore", new Amministratore());
        return "login";
    }

    @RequestMapping(value={"*/logout"}, method={org.springframework.web.bind.annotation.RequestMethod.GET})
    public String logoutPage(HttpServletRequest request, HttpServletResponse response) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null) {
            new SecurityContextLogoutHandler().logout(request, response, auth);
        }
        return "redirect:/login?logout";
    }

    @RequestMapping(value={"/role"}, method={org.springframework.web.bind.annotation.RequestMethod.GET})
    public String loginRole(Model model, HttpSession session) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String role = auth.getAuthorities().toString();
        Utente utente = utenteRepository.findByUsername(auth.getName());
        Amministratore amministratore = amministratoreRepository.findByUsername(auth.getName());
        String targetUrl = "";
        if (role.contains("ROLE_USER")) {
            session.setAttribute("utente", utente);
            model.addAttribute("student", utente);
            targetUrl = "utente/homeUtente";
        } else if (role.contains("ROLE_ADMIN")) {
            session.setAttribute("amministratore", amministratore);
            model.addAttribute("amministratore", amministratore);
            targetUrl = "amministratore/homeAmministratore";
        }
        return targetUrl;
    }

}
