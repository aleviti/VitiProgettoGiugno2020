package it.uniroma3.controller;



import java.util.Calendar;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import it.uniroma3.model.Progetto;
import it.uniroma3.model.Task;
import it.uniroma3.repository.ProgettoRepository;
import it.uniroma3.repository.TaskRepository;

@Controller
public class TaskController {

	


	@Autowired
    private TaskRepository taskRepository;
	
  
	@Autowired
    private ProgettoRepository progettoRepository;


	
	
  
    
	
	 @RequestMapping(value={"/toaddTask"}, method={org.springframework.web.bind.annotation.RequestMethod.GET})
	    public String toAddTask(Model model)
	    {
	
		
	     model.addAttribute("task", new Task());
	     model.addAttribute("progetto", new Progetto());
	    return "task";
	    }
	 
	 @RequestMapping(value={"/toaddTask"}, method={org.springframework.web.bind.annotation.RequestMethod.POST})
	    public String addTask(Model model, @ModelAttribute Task task,@ModelAttribute("dataCreazione") String dataInizio, HttpSession session, Object progetto) {
		 
		
         
		 Calendar sysdate = Calendar.getInstance();
	     
	     task.setDataCreazione(sysdate.getTime());
		 model.addAttribute("task", task); 
		
		model.addAttribute("progetto", progetto); 
		 taskRepository.save(task);
		 return "utente";
}
}
