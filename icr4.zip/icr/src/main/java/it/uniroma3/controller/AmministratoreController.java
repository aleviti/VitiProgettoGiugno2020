package it.uniroma3.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.model.Amministratore;
import it.uniroma3.model.Utente;
import it.uniroma3.model.Progetto;
import it.uniroma3.repository.AmministratoreRepository;
import it.uniroma3.repository.ProgettoRepository;
import it.uniroma3.repository.TaskRepository;
import it.uniroma3.repository.UtenteRepository;
@Controller
public class AmministratoreController {
	  @Autowired
	    private AmministratoreRepository amministratoreRepository;
	  
	  @Autowired
	    private UtenteRepository utenteRepository;
	  @Autowired
	    private ProgettoRepository progettoRepository;
	  @Autowired
	    private TaskRepository taskRepository;
	  
	 
	  @RequestMapping(value = "/cancellazioneUtente/{id}", method ={org.springframework.web.bind.annotation. RequestMethod.GET})
		public String cancellazioneUtente(@PathVariable("id") Long id, Model model) {
		 
		  return "homeAmministratore";	
}
	  @RequestMapping(value = "/cancellazioneProgetti/{id}", method ={org.springframework.web.bind.annotation. RequestMethod.GET})
		public String cancellazioneProgetti(@PathVariable("id") Long id, Model model) {
		 
		  return "homeAmministratore";	
}
	  @RequestMapping(value = "/cancellazioneTask/{id}", method ={org.springframework.web.bind.annotation. RequestMethod.GET})
		public String cancellazioneTask(@PathVariable("id") Long id, Model model) {
		 
		  return "homeAmministratore";	
	}
}