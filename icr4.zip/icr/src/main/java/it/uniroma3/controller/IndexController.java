package it.uniroma3.controller;

import it.uniroma3.model.Amministratore;
import it.uniroma3.repository.AmministratoreRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
public class IndexController {

    @Autowired
    private AmministratoreRepository amministratoreRepository;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String goToIndex() {

        List<Amministratore> admins = (List<Amministratore>)amministratoreRepository.findAll();

        if(admins.size() == 0 || admins == null || admins.isEmpty()) {
            Amministratore admin = new Amministratore();
            admin.setUsername("admin");
            admin.setPassword("password");
            amministratoreRepository.save(admin);
        }

        return "index";
    }

    @RequestMapping("/")
    public void handleRequest() {
        throw new RuntimeException("test exception");
    }


}
