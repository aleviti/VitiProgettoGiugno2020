package it.uniroma3.controller;

import java.text.SimpleDateFormat;

import java.util.Date;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import it.uniroma3.model.Progetto;

import java.text.ParseException;

import it.uniroma3.repository.ProgettoRepository;

@Controller
public class ProgettoController {
	@Autowired
    private ProgettoRepository progettoRepository;
	
	@InitBinder
    public void initBinder(WebDataBinder binder) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
        dateFormat.setLenient(false);
        binder.registerCustomEditor(Date.class, new CustomDateEditor( dateFormat, true));
    }
	
	@RequestMapping(value={"/creaProgetto"}, method={org.springframework.web.bind.annotation.RequestMethod.GET})
    public String toCreaProgetto(Model model)
    {
		
        model.addAttribute("progetto", new Progetto());
        return "progetto";
    }
 
 @RequestMapping(value={"/creaProgetto"}, method={org.springframework.web.bind.annotation.RequestMethod.POST})
    public String creaProgetto(Model model, @ModelAttribute Progetto progetto,@ModelAttribute("dataInizio") String dataInizio, HttpSession session) throws ParseException {

	 
	 model.addAttribute("progetto", progetto); 
	 SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-mm-dd");
     progetto.setDataInizio(simpleDateFormat.parse(dataInizio));
	 
    
	 progettoRepository.save(progetto);
	 return "utente";
}
 
}